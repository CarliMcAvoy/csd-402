package csd402.Module9;
import java.util.ArrayList;
import java.util.Scanner;

public class Exception {
    public static void main(String[] args) {
        Scanner input  = new Scanner(System.in);
        boolean continueInput = true;

        ArrayList<String> mainList = new ArrayList<String>();
        mainList.add("Naruto");
        mainList.add("Raju");
        mainList.add("Evangelion");
        mainList.add("Jujutsu");
        mainList.add("Frieren");
        mainList.add("Bleach");
        mainList.add("One Piece");
        mainList.add("Kaiju");
        mainList.add("Another");
        mainList.add("Undertale");

        displayList(mainList);

        do {
            System.out.println("Which element would you like to see again? ");
            String element = input.nextLine();
            displayElement(element, mainList);
            System.out.println();

            if (!mainList.contains(element)) {
                continueInput = false;
            }
        }while(continueInput);
    }


    public static void displayList (ArrayList<String> list){
        for (String i : list){
            System.out.println(i);
        }
        System.out.println();
    }


    public static void displayElement (String element, ArrayList<String> list){
        int i;

        try {
            for (i = 0; i < list.size(); i++) {
                if (element.equals(list.get(i))) {
                    System.out.println(list.get(i));
                }
            }
        }
        catch (IndexOutOfBoundsException e) {
            System.out.println("Out of Bounds");
        }
    }
}
