package csd402.Module9;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

public class Files {
    public static void main(String[] args) {
        Random random = new Random();

        //create file
        File dataFile = null;
        try {
            dataFile = new File("data.file");
            if (dataFile.createNewFile()) {
                System.out.println("File " + dataFile.getName() + " created");
            } else {
                System.out.println("File " + dataFile.getName() + " already exists");
            }

        //write to file
            PrintWriter writeFile = new PrintWriter("data.file");

            for (int i = 0; i < 10; i++) {
                int data = random.nextInt(11);
                writeFile.print(data);
                writeFile.print(" ");
            }
            writeFile.close();
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }

        //read file
        try (Scanner read = new Scanner(dataFile)) {
            while (read.hasNext()) {
                String line = read.next();
                System.out.print(line + " ");
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
